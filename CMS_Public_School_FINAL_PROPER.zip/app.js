const school={
 name:"CMS Public School",address:"Mitthaulli, Mathura, Uttar Pradesh, India",
 director:"Harendra Singh",directorQ:"BCA, BA, B.Ed.",
 principal:"Napolian Peter",principalQ:"M.A., B.Ed.",
 email:"cmspubschool@gmail.com",phones:["9805370967","8872947490"]
};
const classes=["Nursery","LKG","UKG",...Array.from({length:12},(_,i)=>"Class "+(i+1))];
const facilities=["Smart Classrooms","Computer Lab","Science Lab","Mathematics Lab","Playground","Gymnasium","Extracurricular Activities","Environment-friendly Campus","Social Service Activities"];

function go(page){
 document.getElementById("nav").classList.remove("show");
 const A=document.getElementById("app");
 const pages={
 home:`<section class="hero"><div><small class="eyebrow">CMS PUBLIC SCHOOL · MITTHAULLI, MATHURA</small><h1>Where learning<br><em>meets character.</em></h1><p>English-medium, co-educational education with activity-based learning, discipline, creativity, sports and community.</p><div class="actions"><button class="pink" onclick="go('enquiry')">Admission Enquiry →</button><button onclick="go('gallery')">View Gallery</button><button onclick="go('about')">Explore School</button></div></div><div class="hero-card"><div class="orbit"><span class="logo-fallback big">CMS</span></div><b>Learning · Character · Excellence</b><small>Student-focused school experience</small></div></section><div class="ticker">✦ EDUCATION ✦ DISCIPLINE ✦ CHARACTER ✦ CREATIVITY ✦ SPORTS ✦ COMMUNITY ✦</div><section class="section"><small class="eyebrow">01 — OUR SCHOOL</small><h2>Growing minds.<br><em>Building values.</em></h2><div class="grid">${cards([["01","Learning First","Concepts, communication, curiosity and consistent progress."],["02","Holistic Growth","Sports, culture, practical activities and community learning."],["03","Strong Community","Students, teachers and families growing together."]])}</div></section>`,
 about:page("About Us",`<div class="grid">${cards([["01","Our Approach","Activity-based learning that connects classroom concepts with practical experiences."],["02","Our Medium","English-medium education in a co-educational school environment."],["03","Our Community","A disciplined, respectful environment focused on learning and character."]])}</div><div class="people"><article><small>DIRECTOR</small><h3>${school.director}</h3><p>${school.directorQ}</p></article><article><small>PRINCIPAL</small><h3>${school.principal}</h3><p>${school.principalQ}</p></article></div>`),
 academics:page("Academics",`<p>Core public-school classes are Nursery through Class 8. The ERP is designed to remain extensible through Classes 9–12.</p><div class="chips">${classes.map(c=>`<span>${c}</span>`).join("")}</div>`),
 facilities:page("Facilities",`<div class="grid">${facilities.map((x,i)=>`<article class="card"><small>0${i+1}</small><h3>${x}</h3><p>Facility information can be maintained from the school ERP.</p></article>`).join("")}</div>`),
 faculty:page("Faculty",`<div class="notice"><b>Faculty Directory</b><p>Only approved teacher profiles are published here. Teacher applications remain private until Admin approval.</p></div>`),
 admissions:page("Admissions",`<div class="grid">${cards([["01","Admission Enquiry","Send an enquiry to the school office."],["02","Documents","Admission documents are handled through protected storage."],["03","Application Status","ERP-ready workflow for application progress."]])}</div><button class="pink" onclick="go('enquiry')">Start Enquiry →</button>`),
 gallery:page("Gallery",`<div class="gallery"><div><span class="logo-fallback big">CMS</span><h3>School Gallery</h3><p>Put the previously supplied Base64/image assets in this project's asset bundle to display the original gallery.</p></div></div>`),
 achievements:page("Achievements",`<div class="notice"><b>Achievements</b><p>Admin-managed achievement entries and photos are supported by the ERP schema.</p></div>`),
 events:page("Events",`<div class="notice"><b>Events & Recent Moments</b><p>Admin/Clerk can publish school events and moments to the public website.</p></div>`),
 notices:page("Notice Board",`<div id="publicNotices" class="notice"><b>Notice Board</b><p>Published notices will appear here when Supabase credentials are configured.</p></div>`),
 enquiry:page("Enquiry Office",`<form onsubmit="submitEnquiry(event)"><input id="parent" required placeholder="Parent / Guardian name"><input id="mobile" required type="tel" placeholder="Mobile number"><input id="email" type="email" placeholder="Email"><select id="className"><option value="">Class required</option>${classes.map(c=>`<option>${c}</option>`).join("")}</select><textarea id="message" placeholder="Message"></textarea><button class="pink">Submit Enquiry</button><p id="formMsg"></p></form>`),
 contact:page("Contact Us",`<div class="contact"><h3>${school.name}</h3><p>📍 ${school.address}</p><p>✉ ${school.email}</p><p>☎ ${school.phones.join(" / ")}</p></div>`)
 };
 A.innerHTML=pages[page]||pages.home; scrollTo({top:0,behavior:"smooth"});
}
function cards(items){return items.map(x=>`<article class="card"><small>${x[0]}</small><h3>${x[1]}</h3><p>${x[2]}</p></article>`).join("")}
function page(title,body){return `<section class="page-head"><small>CMS PUBLIC SCHOOL</small><h1>${title}</h1></section><section class="section">${body}</section>`}
function toggleMenu(){document.getElementById("nav").classList.toggle("show")}
function openPortal(){
 const m=document.createElement("div");m.className="modal";m.id="modal";
 m.innerHTML=`<div class="modalbox"><button class="close" onclick="closeModal()">×</button><div class="portalhead"><span class="logo-fallback">CMS</span><h2>Welcome Back 👋</h2><p>Good to see you again at CMS Public School</p></div><div class="tabs">${["student","teacher","admin","clerk"].map((r,i)=>`<button class="${i===0?'active':''}" onclick="portalRole(this,'${r}')">${r}</button>`).join("")}</div><div id="loginArea"></div></div>`;
 document.body.appendChild(m);portalRole(document.querySelector(".tabs button"),"student");
}
function portalRole(btn,role){document.querySelectorAll(".tabs button").forEach(x=>x.classList.remove("active"));btn.classList.add("active");const staff=role==="admin"||role==="clerk";document.getElementById("loginArea").innerHTML=staff?`<div class="security">🔐 ${role.toUpperCase()} — Password + mandatory authenticator-app TOTP</div><form onsubmit="staffLogin(event,'${role}')"><input id="staffId" required placeholder="Staff ID"><input id="staffPassword" required type="password" placeholder="Password"><button class="pink">Continue to 2FA</button><p id="loginMsg"></p></form>`:`<form onsubmit="userLogin(event,'${role}')"><input required placeholder="Email / username"><input required type="password" placeholder="Password"><button class="pink">Sign in</button><button type="button" onclick="googleLogin()">Continue with Google</button></form>`}
function closeModal(){document.getElementById("modal")?.remove()}
function googleLogin(){alert("Google Auth is enabled after configuring the Supabase Google provider.")}
function userLogin(e,role){e.preventDefault();alert(role+" portal authentication is ready for Supabase Auth configuration.")}
function staffLogin(e,role){e.preventDefault();document.getElementById("loginArea").innerHTML=`<h3>Authenticator verification</h3><form onsubmit="verifyTOTP(event,'${role}')"><input required inputmode="numeric" maxlength="6" placeholder="6-digit TOTP code"><button class="pink">Verify & Enter</button><p id="loginMsg">Password accepted only after the server-side staff gate.</p></form>`}
function verifyTOTP(e,role){e.preventDefault();alert("TOTP verification is enforced by Supabase Auth MFA after backend configuration.")}
function submitEnquiry(e){e.preventDefault();document.getElementById("formMsg").textContent="Enquiry form is ready. Configure Supabase environment variables to store it in the enquiries table.";document.getElementById("formMsg").className="ok"}
go("home");